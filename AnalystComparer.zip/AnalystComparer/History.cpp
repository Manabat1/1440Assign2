//
// Created by manab on 2/1/2017.
//

#include "History.hpp"
#include "FormattedTable.h"
#include "Utils.h"
#include <fstream>
#include <sstream>

History::History(std::ifstream& fin){
    simDays = atoi(getTrimmedLine(fin).c_str());
    seedMoney= atoi(getTrimmedLine(fin).c_str());
    totalSales = atoi(getTrimmedLine(fin).c_str());
    for(int i = 0; i < totalSales; i++){
        std::string parse;
        std::stringstream ss(parse);
        addPurchaseSale(*(new PurchaseSale(parse)));
    }
    fin.close();
}
void History::addPurchaseSale(PurchaseSale purchaseSale){
    purchaseSales.push_back(purchaseSale);
}
std::vector<PurchaseSale> History::getPurchaseSales(){
    return purchaseSales;
}

void History::printHistory() {
    std::cout << "Example 2: Create a table with 5 columns: Id, First Name, Last Name, GPA, Total Credits" << std::endl;
    std::cout << "           With 4 rows" << std::endl;

    FormattedTable table(4, 5);

    table.addColumn(new ColumnDefinition("Id", 8, ColumnDefinition::Integer, ColumnDefinition::Center));
    table.addColumn(new ColumnDefinition("First Name", 20, ColumnDefinition::String));
    table.addColumn(new ColumnDefinition("Last Name", 20, ColumnDefinition::String));
    table.addColumn(new ColumnDefinition("GPA", 8, ColumnDefinition::FixedPrecision, ColumnDefinition::Right, 1));
    table.addColumn(new ColumnDefinition("Total Credits", 14, ColumnDefinition::Integer));

    FormattedRow* row = new FormattedRow(&table);
    row->addCell(new FormattedCell((int) 1));
    row->addCell(new FormattedCell("Joe"));
    row->addCell(new FormattedCell("Jones"));
    row->addCell(new FormattedCell((float) 3.84));
    row->addCell(new FormattedCell((int) 84));
    table.addRow(row);

    row = new FormattedRow(&table);
    row->addCell(new FormattedCell((int) 2));
    row->addCell(new FormattedCell("Sue"));
    row->addCell(new FormattedCell("Samuelson"));
    row->addCell(new FormattedCell((float) 3.65));
    row->addCell(new FormattedCell((int) 64));
    table.addRow(row);

    row = new FormattedRow(&table);
    row->addCell(new FormattedCell((int) 3));
    row->addCell(new FormattedCell("Tammy"));
    row->addCell(new FormattedCell("Thompson"));
    row->addCell(new FormattedCell((float) 3.57));
    row->addCell(new FormattedCell((int) 97));
    table.addRow(row);

    row = new FormattedRow(&table);
    row->addCell(new FormattedCell((int) 4));
    row->addCell(new FormattedCell("Charles"));
    row->addCell(new FormattedCell("Carlson"));
    row->addCell(new FormattedCell((float) 3.43));
    row->addCell(new FormattedCell((int) 46));
    table.addRow(row);

    std::cout << "           And, then write to the standard output stream" << std::endl << std::endl;

    table.write(std::cout);

    std::cout << std::endl << "Done" << std::endl << std::endl;
}
