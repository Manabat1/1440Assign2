//
// Created by manab on 2/1/2017.
//
#include <fstream>
#include "Analyst.hpp"
#include "Utils.h"

Analyst::Analyst(std::string fileName){
    std::ifstream fin;
    fin.open(fileName);
    if(fin.fail()){
        std::cout << "Failed" << std::endl;
    }
    std::string line;
    name = getTrimmedLine(fin);
    initials = getTrimmedLine(fin);
    hist = new History(fin);
}

std::string Analyst::getName() const {
    return name;
}

History Analyst::getHistory(){
    return *hist;
}
