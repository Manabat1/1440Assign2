//
// Created by manab on 2/1/2017.
//

#include <vector>
#include <sstream>
#include "PurchaseSale.hpp"
#include "Utils.h"


PurchaseSale::PurchaseSale(std::string& toSplit){
    std::string store;
    int iter=0;

    while(std::getline(toSplit,store, ',')){
      switch(iter){
          case 0 :
            m_symbol = store;
              break;
          case 1 :
              m_quantity = stoi(store);
              break;
          case 2 :
              m_purchaseTime = stoi(store);
              break;
          case 3 :
              m_purchasePrice = stoi(store);
              break;
          case 4 :
              m_purchaseFee = stoi(store);
              break;
          case 5 :
              m_saleTime = stoi(store);
              break;
          case 6 :
              m_salePrice = stoi(store);
              break;
          case 7 :
              m_saleFee = stoi(store);
              break;
      }
      iter++;

        std::cout << "m_purchaseFee" <<m_purchaseFee << std::endl;
        std::cout << "m_saleTime" <<m_saleTime << std::endl;
    }

}
int PurchaseSale::computeInvestmentAmount() const {
    return m_quantity*m_purchasePrice + m_purchaseFee + m_saleFee;
}
int PurchaseSale::computeProfit() const {
    return m_quantity*m_salePrice - computeInvestmentAmount();
}

std::string PurchaseSale::getSymbol() const{
    return m_symbol;
}
