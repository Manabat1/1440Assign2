//
// Created by Stephen Clyde on 1/16/17.
//

#include <iostream>
#include <fstream>
#include <iomanip>
#include "Comparer.h"
#include "FormattedTable.h"


int Comparer::load(int argc, char* argv[])
{
    if (argc<3)
    {
        std::cout << "Invalid parameters" << std::endl;
        std::cout << "usage: AnalystComparer <output file> <input file 1> <input file 2> ..." << std::endl;
        return -1;
    }

    m_outputFilename = argv[1];
    m_analystCount = argc - 2;

    int analystIndex = 0;
    for (int i = 0; i < m_analystCount; i++)
    {
        //std::ifstream inputStream(argv[2 + analystIndex]);
        m_analysts.push_back(*(new Analyst((argv[2 + analystIndex]))));
        analystIndex++;
    }
   loadSymbols();

    return 0;
}

int Comparer::compare()
{
    if (m_analystCount < 2)
    {
        std::cout << "Cannot do comparison with " << m_analystCount << " analysts" << std::endl;
        return -1;
    }

    if (m_outputFilename == "")
    {
        std::cout << "Cannot do comparison because no output file is specified" << std::endl;
        return -1;
    }

    std::ofstream outputStream(m_outputFilename);
    outputStream.open(m_outputFilename);
    outputInvestorNames(outputStream);
    outputOverallPerformance(outputStream);
    outputStockPerformance(outputStream);
    outputStream.close();

    return 0;
}

void Comparer::loadSymbols()
{
    //Loops through the analysts
    for(int i = 0; i < m_analysts.size(); i++){
        std::vector<PurchaseSale*> sales = (m_analysts[i].getHistory().getPurchaseSales());
       // std::cout << "Hello?" << std::endl;
        //Loops through the sales
        for(int j = 0; j < sales.size(); j++){

            //Loops through the symbols
            bool symbolFound = false;
            std::string theString="";
            for(int k = 0; k < m_symbols.size(); k++){
                // if match is found, break loop
                if(m_symbols[k] == sales[j]->getSymbol()){
                    symbolFound = true;
                }
            }
            if(!symbolFound){
                m_symbols.push_back(sales[j]->getSymbol());
                //std::cout << "Adding symbol"<< sales[j]->getSymbol() << std::endl;
            }
        }
    }
    // Adds the symbol to the symbols if it is not already in it

}


void Comparer::outputInvestorNames(std::ofstream& outputStream) const
{
    std::cout << "Investors:\n";
    for(int i = 0; i < m_analysts.size(); i++){
        std::cout << m_analysts[i].getName() <<"\n";
    }
    std::cout << "\n";
//     TODO: Write out investor names
}

void Comparer::outputOverallPerformance(std::ofstream& outputStream)
{
    // TODO: Write out Overall Performance table.  The classes from the FormattedTable example might be helpful.

    std::cout << "Overall Preformance:\n";
    FormattedTable table(4, m_analystCount+1);

    table.addColumn(new ColumnDefinition("Info", 20, ColumnDefinition::String, ColumnDefinition::Center));
    for(int i =0; i< m_analystCount; i ++){
        table.addColumn(new ColumnDefinition(m_analysts[i].getName(), 20, ColumnDefinition::String));
    }

    FormattedRow* row = new FormattedRow(&table);
    row->addCell(new FormattedCell("D (days)"));
    for(int i =0; i< m_analysts.size(); i ++){
        std::string toAdd = std::to_string(m_analysts[i].getHistory().getSimDays());
        row->addCell(new FormattedCell(toAdd));
    }

    table.addRow(row);
    row->addCell(new FormattedCell("$ (cents)"));
    for(int i =0; i< m_analystCount; i ++){
        row->addCell(new FormattedCell(std::to_string(m_analysts[i].getHistory().getSeedMoney())));
    }
    table.addRow(row);
    row->addCell(new FormattedCell("$ TPL"));
    for(int i =0; i< m_analystCount; i ++){
        row->addCell(new FormattedCell(std::to_string(m_analysts[i].getHistory().getTotalProfit())));
    }
    table.addRow(row);
    row->addCell(new FormattedCell("$ PLPD"));
    for(int i =0; i< m_analystCount; i ++){
        row->addCell(new FormattedCell(std::to_string(m_analysts[i].getHistory().getTotalProfit()/m_analysts[i].getHistory().getSimDays())));
    }
    table.addRow(row);

    table.write(std::cout);
    std::cout << "\n";
};

void Comparer::outputStockPerformance(std::ofstream& outputStream)
{
    std::cout << "Stock Preformance: \n";
    FormattedTable table(m_symbols.size()+1, m_analystCount+1);

    table.addColumn(new ColumnDefinition("Symbol", 10, ColumnDefinition::String, ColumnDefinition::Center));
    for(int i =0; i< m_analystCount; i ++){
        table.addColumn(new ColumnDefinition(m_analysts[i].getName(), 10, ColumnDefinition::String));
    }

    FormattedRow* row = new FormattedRow(&table);
    for(int j = 0; j<m_symbols.size(); j++) {
        row->addCell(new FormattedCell(m_symbols[j]));
        for (int i = 0; i < m_analysts.size(); i++) {
            float tplpd= 0.0;
            for (int i = 0; i < m_analysts[i].getHistory().purchaseSales.size(); i++) {
                if(m_analysts[i].getHistory().purchaseSales[i]->getSymbol() == m_symbols[j]){
                    tplpd += m_analysts[i].getHistory().purchaseSales[i]->computeProfit();
                }
            }
            std::string toAdd = std::to_string(tplpd);
            row->addCell(new FormattedCell(toAdd));
        }
        std::cout << "Adding another row";
        table.addRow(row);
    }

    table.write(std::cout);
    std::cout << "\n";
}
