//
// Created by Stephen Clyde on 1/16/17.
//

#include <iostream>
#include <fstream>
#include <iomanip>
#include "Comparer.h"


int Comparer::load(int argc, char* argv[])
{
    if (argc<3)
    {
        std::cout << "Invalid parameters" << std::endl;
        std::cout << "usage: AnalystComparer <output file> <input file 1> <input file 2> ..." << std::endl;
        return -1;
    }

    m_outputFilename = argv[1];
    m_analystCount = argc - 2;

    int analystIndex = 0;
    for (int i = 0; i < m_analystCount; i++)
    {
        //std::ifstream inputStream(argv[2 + analystIndex]);
        m_analysts.push_back(*(new Analyst((argv[2 + analystIndex]))));
        analystIndex++;
    }
    std::cout << m_analysts.size() << std::endl;
    //loadSymbols();

    int result = 0;
    if (analystIndex < m_analystCount)
        result = -1;
    return result;
}

int Comparer::compare() const
{
    if (m_analystCount < 2)
    {
        std::cout << "Cannot do comparison with " << m_analystCount << " analysts" << std::endl;
        return -1;
    }

    if (m_outputFilename == "")
    {
        std::cout << "Cannot do comparison because no output file is specified" << std::endl;
        return -1;
    }

    std::ofstream outputStream(m_outputFilename);
    outputInvestorNames(outputStream);
    outputOverallPerformance(outputStream);
    outputStockPerformance(outputStream);

    return 0;
}

void Comparer::loadSymbols()
{
    //Loops through the analysts
    for(int i = 0; i < m_analysts.size(); i++){
        std::vector<PurchaseSale> sales = (m_analysts[i].getHistory().getPurchaseSales());
        //Loops through the sales
        for(int j = 0; j < sales.size(); j++){
            //Loops through the symbols
            for(int k = 0; k <= m_symbols.size(); k++){
                //last loop through, no match found
                if(k == (m_symbols.size())){
                    m_symbols.push_back(sales[j].getSymbol());
                    break;
                }
                // if match is found, break loop
                if(m_symbols[j] == sales[j].getSymbol()){
                    break;
                }

            }
        }
    }
    // Adds the symbol to the symbols if it is not already in it

}


void Comparer::outputInvestorNames(std::ofstream& outputStream) const
{
    std::cout << "Investors:" << std::endl;
    for(int i = 0; i < m_analysts.size(); i++){
        std::cout << "   " << m_analysts[i].getName() << std::endl;
    }
    // TODO: Write out investor names
}

void Comparer::outputOverallPerformance(std::ofstream& outputStream) const
{
    // TODO: Write out Overall Performance table.  The classes from the FormattedTable example might be helpful.
};

void Comparer::outputStockPerformance(std::ofstream& outputStream) const
{
    // TODO: Write out Stock Performance table.  The classes from the FormattedTable example might be helpful.
}
